var express = require('express'),
    app = express(),
    server = require('http').createServer(app),
    io = require('socket.io').listen(server),
    users = [];
//specify the html we will use

app.use('/', express.static(__dirname + '/www'));


//bind the server to the 80 port
//server.listen(3000);//for local test

server.listen(process.env.PORT || 3000);

io.sockets.on('connection', function(socket) {
    //new user login
    socket.on('rooms', function(join) {
       
        switch (join) {
            case 1 : if(rooms == rooms && masterid == masterid )
                        {
                            "요 마스터"
                            socket.emit('loginSuccess');
                            io.sockets.emit('system', nickname, users.length, 'login'); 
                        }
                        break;

            case 2: if(currentCost >= maxcost)
                        {
                            alert('People excess');
                        }
                        break;

            default: 
                    if(status == T)
                    {
                        socket.emit('loginSuccess');
                        io.sockets.emit('system', nickname, users.length, 'login'); 
                    }
                    else
                    {
                        alert('block');
                    }
            break;
          }

       
    });

    //user leaves
    socket.on('disconnect', function() {
        if (socket.nickname != null) {
            //users.splice(socket.userIndex, 1);
            users.splice(users.indexOf(socket.nickname), 1);
            socket.broadcast.emit('system', socket.nickname, users.length, 'logout');
        }
    });



    //new message get
    socket.on('postMsg', function(msg, color) {
        socket.broadcast.emit('newMsg', socket.nickname, msg, color);
    });
   
});
